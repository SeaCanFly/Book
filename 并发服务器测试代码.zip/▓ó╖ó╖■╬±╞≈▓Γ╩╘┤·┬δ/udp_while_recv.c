#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

int main(int argc, char *argv[])
{
	unsigned short port = 8080;	// 本地端口

	int sockfd;
	sockfd = socket(AF_INET, SOCK_DGRAM, 0); // 创建udp套接字
	if(sockfd < 0)
	{
		perror("socket");
		exit(-1);
	}
	
	// 配置本地网络信息
	struct sockaddr_in my_addr;
	bzero(&my_addr, sizeof(my_addr));	// 清空
	my_addr.sin_family = AF_INET;		// IPv4
	my_addr.sin_port   = htons(port);	// 端口
	my_addr.sin_addr.s_addr = htonl(INADDR_ANY); // ip
	
	printf("Binding server to port %d\n", port);
	
	// 绑定
	int err_log;
	err_log = bind(sockfd, (struct sockaddr*)&my_addr, sizeof(my_addr));
	if(err_log != 0)
	{
		perror("bind");
		close(sockfd);		
		exit(-1);
	}
	
	printf("receive data...\n");
	while(1)
	{
		int recv_len;
		char recv_buf[512] = {0};
		struct sockaddr_in client_addr;
		char cli_ip[INET_ADDRSTRLEN] = "";//INET_ADDRSTRLEN=16
		socklen_t cliaddr_len = sizeof(client_addr);
		
		// 接收客户端数据
		recv_len = recvfrom(sockfd, recv_buf, sizeof(recv_buf), 0, (struct sockaddr*)&client_addr, &cliaddr_len);
		
		// 处理数据，这里只是把接收过来的数据打印
		inet_ntop(AF_INET, &client_addr.sin_addr, cli_ip, INET_ADDRSTRLEN);
		printf("\nip:%s ,port:%d\n",cli_ip, ntohs(client_addr.sin_port)); // 客户端的ip
		printf("data(%d):%s\n",recv_len,recv_buf);	// 客户端的数据
		
		// 反馈结果，这里把接收直接到客户端的数据回复过去
		sendto(sockfd, recv_buf, recv_len, 0, (struct sockaddr*)&client_addr, cliaddr_len);
	}
	
	close(sockfd);
	
	return 0;
}